package com.example.cw4b2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText c = findViewById(R.id.editTextTextPersonName6) ;
        final EditText v= findViewById(R.id.editTextTextPersonName7) ;
        final EditText b = findViewById(R.id.editTextTextPersonName8) ;
        final EditText n = findViewById(R.id.editTextTextPersonName9) ;
        Button h = findViewById(R.id.button) ;
        Button k = findViewById(R.id.button2) ;
        Button f = findViewById(R.id.button3) ;
        TextView g = findViewById(R.id.textView2);



       h.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               int n1 =Integer.parseInt(c.getText().toString());
               int n2 =Integer.parseInt(v.getText().toString());
               int n3 =Integer.parseInt(b.getText().toString());
               int n4 =Integer.parseInt(n.getText().toString());
               int sum =n1+n2+n3+n4;
               Toast.makeText(MainActivity.this, sum + "", Toast.LENGTH_SHORT).show();




           }
       });


       k.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               int n1 =Integer.parseInt(c.getText().toString());
               int n2 =Integer.parseInt(v.getText().toString());
               int n3 =Integer.parseInt(b.getText().toString());
               int n4 =Integer.parseInt(n.getText().toString());
               int sum =n1+n2+n3+n4;
               




           }
       });









    }

}